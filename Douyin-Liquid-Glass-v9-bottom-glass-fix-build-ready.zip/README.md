
## This build
- Version 1.0.1 (131)
- Adds a persistent "底栏大小" slider (70%–130%, default 100%).
- The setting applies to the whole liquid-glass bottom control group immediately.

# Douyin-Liquid-Glass

LiquidGlass For Douyin.抖音底栏液态玻璃

## 状态

- 版本：`1.0.0`
- 适配抖音版本：`39.2.0`
- 已测试系统：
  - Android 13 - ColorOS 13 / MIUI 14
  - Android 15 - 澎湃OS 2
  - Android 16 - ColorOS 16

这是一个实验性 LSPosed 项目，仅供学习、参考和娱乐使用。当前版本为最终发布存档，发布后不再继续维护或修复问题。

## 说明

- 本项目与抖音、字节跳动无关。
- 本项目不收集用户数据，所有操作均在本地完成。
- 使用风险由使用者自行承担，请勿用于商业用途或违规用途。

## APK

已签名 APK 位于仓库根目录：

`Douyin-Liquid-Glass-v1.0.0-release.apk`


## v7
- Fixed video progress-bar touch by forwarding progress gestures from the glass overlay window to Douyin native progress controls.
## v9
- Fixed the bottom liquid-glass overlay leaving an exposed dark/native region beside the `我的` tab by making the overlay window full-width while keeping the capsule's own edge inset.
- Preserved the four-tab layout: `首页 / 朋友 / 消息 / 我的`; the publish/+ control is not part of the liquid-glass tab group.
- Fixed persisted `底栏长度` settings to consistently accept `70%–200%`.
- Version: `1.0.4` (134).

