package com.autumn.douyin.liquidglass.ui

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import android.os.SystemClock
import com.autumn.douyin.liquidglass.ModuleLog

/**
 * Diagnostic-only, read-only pixel scan (handoff doc section 6.D).
 *
 * Scans the right-edge portion of the already-captured composite bitmap for
 * a contiguous near-black region and logs its bounding box in the same
 * coordinate space as [DynamicBitmapBackdrop.compositeCaptureRect], so it can
 * be correlated against the "capsule geometry snapshot" and
 * "backdrop geometry" log lines emitted from the same capture pass.
 *
 * This proves *that* black pixels exist and *where*, in screen coordinates.
 * It does NOT identify which layer painted them -- that requires combining
 * this bounding box with the native-view dump and the Compose geometry
 * snapshot, per the handoff doc's explicit warning in section 6.D.
 *
 * Read-only: never mutates the bitmap, and only reads a small right-edge
 * slice of it (not the full frame) to keep this cheap enough to run on a
 * capture cadence rather than only on demand.
 */
object BlackRegionPixelScanner {

    // Empirically "black-ish": low RGB and reasonably opaque. Loosened
    // slightly from pure black (0,0,0) because the actual artifact may be
    // anti-aliased or blended with a translucent layer at its edges.
    private const val ChannelThreshold = 24
    private const val MinAlpha = 64

    // Only scan the rightmost slice of the capture, since the reported
    // artifact sits at the right edge next to "我的". Scanning the full
    // capsule width on every frame would be wasted work.
    private const val ScanSliceWidthPx = 160

    // Throttle: the composite frame can update far more often than this
    // scan needs to run to be useful for the size-sweep test procedure.
    private const val MinScanIntervalMs = 250L

    private var lastScanElapsedRealtime = 0L

    fun maybeScan(bitmap: Bitmap?, captureRect: Rect, label: String) {
        if (!ModuleLog.isEnabled) return
        if (bitmap == null || bitmap.isRecycled) return
        if (captureRect.isEmpty) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastScanElapsedRealtime < MinScanIntervalMs) return
        lastScanElapsedRealtime = now

        runCatching {
            val bitmapW = bitmap.width
            val bitmapH = bitmap.height
            if (bitmapW <= 0 || bitmapH <= 0) return@runCatching

            val sliceLeft = (bitmapW - ScanSliceWidthPx).coerceAtLeast(0)
            val sliceWidth = bitmapW - sliceLeft
            if (sliceWidth <= 0) return@runCatching

            val pixels = IntArray(sliceWidth * bitmapH)
            bitmap.getPixels(pixels, 0, sliceWidth, sliceLeft, 0, sliceWidth, bitmapH)

            var minX = Int.MAX_VALUE
            var minY = Int.MAX_VALUE
            var maxX = Int.MIN_VALUE
            var maxY = Int.MIN_VALUE
            var blackPixelCount = 0

            for (y in 0 until bitmapH) {
                val rowOffset = y * sliceWidth
                for (x in 0 until sliceWidth) {
                    val pixel = pixels[rowOffset + x]
                    if (isBlackish(pixel)) {
                        blackPixelCount++
                        val absX = sliceLeft + x
                        if (absX < minX) minX = absX
                        if (absX > maxX) maxX = absX
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                }
            }

            if (blackPixelCount == 0) {
                ModuleLog.info { "black-pixel scan [$label]: none found in right-edge slice" }
                return@runCatching
            }

            // Bitmap-local bounds -> screen coordinates via captureRect origin.
            // captureRect maps 1:1 onto the bitmap in the existing capture
            // pipeline (see DynamicBitmapBackdrop), so this is a direct offset.
            val screenLeft = captureRect.left + minX
            val screenTop = captureRect.top + minY
            val screenRight = captureRect.left + maxX + 1
            val screenBottom = captureRect.top + maxY + 1

            ModuleLog.info {
                "black-pixel scan [$label]: bitmapLocal=[$minX,$minY,${maxX + 1},${maxY + 1}], " +
                    "screen=[$screenLeft,$screenTop,$screenRight,$screenBottom], " +
                    "widthPx=${screenRight - screenLeft}, heightPx=${screenBottom - screenTop}, " +
                    "pixelCount=$blackPixelCount, scannedSlice=${sliceWidth}x$bitmapH, " +
                    "captureRect=$captureRect"
            }
        }.onFailure { throwable ->
            ModuleLog.error("black-pixel scan failed", throwable)
        }
    }

    private fun isBlackish(pixel: Int): Boolean {
        val alpha = Color.alpha(pixel)
        if (alpha < MinAlpha) return false
        val r = Color.red(pixel)
        val g = Color.green(pixel)
        val b = Color.blue(pixel)
        return r <= ChannelThreshold && g <= ChannelThreshold && b <= ChannelThreshold
    }
}
