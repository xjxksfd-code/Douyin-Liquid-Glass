package com.autumn.douyin.liquidglass.nativebar

import android.view.View
import android.view.ViewGroup
import com.autumn.douyin.liquidglass.ModuleLog

/**
 * Read-only diagnostic scanner for the native Douyin bottom-navigation
 * hierarchy.
 *
 * This does NOT hide, resize, or otherwise mutate any native view. It only
 * walks the hierarchy around [NativeBottomBar.all] and writes a structured
 * dump to [ModuleLog] (gated by the existing diagnosticLoggingEnabled
 * setting), so the real cause of the residual dark region to the right of
 * "我的" can be identified from a captured log/diagnostic bundle instead of
 * being guessed at from resource-ID speculation.
 *
 * Usage: enable diagnostic logging in the module settings, reproduce the
 * black-corner artifact, then pull module.log (or use the in-app "导出诊断包"
 * export) and search for "native bottom bar hierarchy dump". Every child not
 * tagged KNOWN:<name> is a candidate for the leftover view/drawable.
 */
object NativeBottomBarHierarchyDumper {

    private const val MaxClimbHeightDp = 320f
    private const val MaxClimbLevels = 4
    private const val MaxDumpDepth = 14

    fun dump(nativeBar: NativeBottomBar, label: String) {
        if (!ModuleLog.isEnabled) return
        runCatching {
            val anchor = nativeBar.all.firstOrNull() ?: return
            if (!anchor.isAttachedToWindow) return

            val dumpRoot = findDumpRoot(anchor) ?: return
            val knownByIdentity = buildKnownMap(nativeBar)

            val builder = StringBuilder()
            builder.append("==== native bottom bar hierarchy dump [").append(label).append("] ====\n")

            builder.append("-- known views (from NativeBottomBarLocator) --\n")
            nativeBar.all.forEachIndexed { index, view ->
                val tag = knownByIdentity[System.identityHashCode(view)] ?: "tab$index"
                builder.append("  KNOWN:").append(tag).append(" -> ").append(describe(view)).append('\n')
            }

            builder.append("-- profile (\"我的\") bounds in window --\n")
            builder.append("  ").append(describe(nativeBar.profile)).append('\n')

            val profileLocation = IntArray(2)
            val profileRightEdgePx = if (nativeBar.profile.isAttachedToWindow) {
                nativeBar.profile.getLocationInWindow(profileLocation)
                profileLocation[0] + nativeBar.profile.width
            } else {
                null
            }

            builder.append("-- subtree from ").append(dumpRoot.javaClass.name)
                .append(" (climbed from anchor parent) --\n")
            dumpRecursive(dumpRoot, 0, builder, knownByIdentity, profileRightEdgePx)

            ModuleLog.info(builder.toString())
        }.onFailure { throwable ->
            ModuleLog.error("native bottom bar hierarchy dump failed", throwable)
        }
    }

    private fun buildKnownMap(nativeBar: NativeBottomBar): Map<Int, String> = mapOf(
        System.identityHashCode(nativeBar.home) to "home(首页)",
        System.identityHashCode(nativeBar.friends) to "friends(朋友)",
        System.identityHashCode(nativeBar.plus) to "plus(+)",
        System.identityHashCode(nativeBar.messages) to "messages(消息)",
        System.identityHashCode(nativeBar.profile) to "profile(我的)",
    )

    /**
     * Climbs from the shared tab container upward through compact ancestors
     * only (mirrors the height guard used for background clearing), so the
     * dump also captures any sibling surface sitting just outside the row
     * container itself, without accidentally walking into the full-screen
     * activity root.
     */
    private fun findDumpRoot(anchor: View): ViewGroup? {
        // Defensive fallback: NativeBottomBar.all should always have a
        // ViewGroup ancestor in practice, but avoid a hard crash in the
        // dumper itself if that assumption is ever violated on some OEM ROM.
        var current = anchor.parent as? ViewGroup
            ?: (anchor.rootView as? ViewGroup)
            ?: (anchor as? ViewGroup)
            ?: return null
        var levels = 0
        while (levels < MaxClimbLevels) {
            val parent = current.parent as? ViewGroup ?: break
            val heightDp = current.height / current.resources.displayMetrics.density
            if (heightDp > MaxClimbHeightDp) break
            current = parent
            levels++
        }
        return current
    }

    private fun dumpRecursive(
        view: View,
        depth: Int,
        builder: StringBuilder,
        knownByIdentity: Map<Int, String>,
        profileRightEdgePx: Int?,
    ) {
        if (depth > MaxDumpDepth) {
            builder.append(indent(depth)).append("...max depth reached, stopping\n")
            return
        }
        val tag = knownByIdentity[System.identityHashCode(view)]
        val suspect = tag == null && isBlackSuspect(view, profileRightEdgePx)
        builder.append(indent(depth))
            .append(
                when {
                    tag != null -> "[KNOWN:$tag] "
                    suspect -> "[BLACK-SUSPECT] "
                    else -> "[child] "
                },
            )
            .append(describe(view))
            .append('\n')

        if (view is ViewGroup) {
            for (index in 0 until view.childCount) {
                dumpRecursive(view.getChildAt(index), depth + 1, builder, knownByIdentity, profileRightEdgePx)
            }
        }
    }

    /**
     * Flags children matching every "worth investigating" criterion from the
     * handoff doc (section 6.A): visible, non-zero size, positioned at/beyond
     * the right edge of the "我的" tab, and carrying a background, foreground,
     * elevation, or alpha that could actually paint pixels. This is a
     * candidate marker only -- it does not prove causation, it narrows the
     * search in a dump that can otherwise be dozens of lines long.
     */
    private fun isBlackSuspect(view: View, profileRightEdgePx: Int?): Boolean {
        if (view.visibility != View.VISIBLE) return false
        if (view.width <= 0 || view.height <= 0) return false
        if (!view.isAttachedToWindow) return false

        val location = IntArray(2)
        view.getLocationInWindow(location)
        val left = location[0]
        if (profileRightEdgePx != null && left + view.width < profileRightEdgePx) return false

        val hasPaintableSurface =
            view.background != null ||
                view.foreground != null ||
                view.elevation > 0f ||
                (view.alpha > 0f && view.alpha < 1f) ||
                (view is ViewGroup && view.childCount == 0 && view.alpha > 0f)

        return hasPaintableSurface
    }

    private fun indent(depth: Int): String = "  ".repeat(depth + 1)

    private fun describe(view: View): String {
        val location = IntArray(2)
        val attached = view.isAttachedToWindow
        if (attached) view.getLocationInWindow(location) else {
            location[0] = -1
            location[1] = -1
        }
        val resourceName = view.id
            .takeIf { it != View.NO_ID }
            ?.let { id -> runCatching { view.resources.getResourceName(id) }.getOrNull() }

        return buildString {
            append("class=").append(view.javaClass.name)
            append(" res=").append(resourceName ?: "no-id")
            append(" id=").append(view.id)
            append(" visibility=").append(visibilityName(view.visibility))
            append(" winBounds=[").append(location[0]).append(',').append(location[1])
                .append(',').append(location[0] + view.width).append(',').append(location[1] + view.height).append(']')
            append(" wh=").append(view.width).append('x').append(view.height)
            append(" xy=").append(view.x).append(',').append(view.y)
            append(" translation=").append(view.translationX).append(',').append(view.translationY)
            append(" alpha=").append(view.alpha)
            append(" background=").append(view.background?.javaClass?.name ?: "null")
            append(" foreground=").append(view.foreground?.javaClass?.name ?: "null")
            append(" elevation=").append(view.elevation)
            append(" clickable=").append(view.isClickable)
            append(" selected=").append(view.isSelected)
            append(" childCount=").append((view as? ViewGroup)?.childCount ?: 0)
        }
    }

    private fun visibilityName(visibility: Int): String = when (visibility) {
        View.VISIBLE -> "VISIBLE"
        View.INVISIBLE -> "INVISIBLE"
        View.GONE -> "GONE"
        else -> visibility.toString()
    }
}
