# Diagnostic-only build — what changed and why

Based on the normal V15 build (matches versionCode 141 / 1.1.1 from the
uploaded zip). versionCode bumped to 143 / "1.1.1-diag1" so you can tell
this build apart from either source zip in logs and in Settings.

No rendering, layout, or view-visibility behavior was changed. Every
addition below is read-only instrumentation gated behind the existing
`diagnosticLoggingEnabled` setting (`ModuleLog.isEnabled`).

## Confirmed before touching any code: the modifier-order diff

Diffed the two uploaded zips directly. v3 is the large-black-region
build — the only functional difference (besides versionCode/versionName)
is in `LiquidGlassOverlayView.kt`:

- **v2 (normal, small artifact):** `.graphicsLayer { ... }` then
  `.onGloballyPositioned { ... }` — the position callback sits *inside*
  the transform, so `coordinates.boundsInRoot()` reports bounds *after*
  `currentBarScale` is applied.
- **v3 (large artifact):** the same two modifiers swapped —
  `.onGloballyPositioned { ... }` then `.graphicsLayer { ... }` — the
  position callback now sits *outside* the transform, so
  `boundsInRoot()` reports the *unscaled* `capsuleWidth`, even though the
  capsule is visually drawn smaller by `currentBarScale`.

This is consistent with hypothesis A: `updateCaptureRegion()` /
`captureRect` downstream of that callback would end up sized for the
unscaled capsule, not the actual rendered (scaled) one — a real, sourced
mechanism for the bar size affecting the artifact, not a guess. It
doesn't yet prove this is the *only* contributor to the small artifact
that's present even in the correctly-ordered v2 build, which is why the
instrumentation below targets that remaining case specifically.

## New/changed instrumentation, mapped to handoff doc section 6

**A. Native View hierarchy** — mostly already present
(`NativeBottomBarHierarchyDumper`, already wired to fire 300ms after
tapping the profile tab). Added:
- A `BLACK-SUSPECT` tag (was described in the doc but not implemented)
  for any unknown child that is visible, non-zero size, positioned at or
  right of the "我的" tab's right edge, and has a background, foreground,
  positive elevation, or partial alpha.
- Also now fires from the same `onGloballyPositioned` callback that
  updates capture geometry (see below), not just on tab click — so a
  hierarchy snapshot exists for every bar-size change during the sweep
  test, not only for the profile-tab-click case.

**B. Liquid Glass geometry** — added. New `ModuleLog.info` in
`LiquidGlassOverlayView`'s `onGloballyPositioned` callback logs
`capsuleWidth`, `currentBarScale`, vertical offset, `boundsInRoot()`,
`capturePaddingPx`, and — the key diagnostic value — the *expected*
scaled width (`capsuleWidth * currentBarScale` in px) next to the
*actual* `boundsInRoot().width`, with the delta pulled out explicitly.
If that delta is non-zero on the normal (v2-ordered) build too, that's
evidence the small residual artifact shares the same root cause as the
large one, just at smaller magnitude.

`DynamicBitmapBackdrop.updateCaptureRegion()` already logged capture
geometry, but only when `overlayView.translationY == 0f` — silently
dropped for any non-zero vertical offset. That gate is removed (now
always logs, with `overlayTranslationY` added to the line) so no sample
is lost during the test sweep.

**C. graphicsLayer state** — added, folded into the same log line as B
(`scaleX`, `scaleY`, `translationY` in px, `transformOrigin`), since it's
produced by the same callback and needs to be read together with B, not
separately.

**D. Black-pixel region** — added: `BlackRegionPixelScanner.kt`. Scans
only the rightmost 160px slice of the already-captured composite bitmap
(no extra capture work) for near-black, reasonably opaque pixels,
throttled to once per 250ms, and logs the bounding box in both
bitmap-local and screen coordinates so it lines up with the `captureRect`
already logged in B. Per the doc's own caveat, this proves pixels exist
and where — it does not by itself identify the source layer.

**E. Time correlation** — no changes needed. `ModuleLog` already
timestamps every line to millisecond precision, and B/C/A above are now
emitted from the same callback invocation, so they land as adjacent log
lines for a given layout pass without needing separate correlation
logic.

## What to do with this build

1. Build via the existing `.github/workflows/build.yml` (unchanged) or
   locally with `./gradlew assembleRelease`. I could not run Gradle in
   this environment (no network access to fetch dependencies), so this
   zip contains only the modified sources, not a rebuilt APK.
2. Enable diagnostic logging in the module settings.
3. Run the size sweep from section 7 of the handoff doc (100/90/80/75/70%),
   restarting Douyin per the doc's note about the temporary white-glass
   state.
4. Pull `module.log` (or use the in-app diagnostic-bundle export) and
   grep for, in order: `capsule geometry snapshot`, `backdrop geometry`,
   `black-pixel scan`, and `BLACK-SUSPECT`, comparing timestamps across
   the four to build the timeline the doc's final objective asks for.

## Files touched

- `app/src/main/java/com/autumn/douyin/liquidglass/ui/LiquidGlassOverlayView.kt`
- `app/src/main/java/com/autumn/douyin/liquidglass/ui/OverlayController.kt`
- `app/src/main/java/com/autumn/douyin/liquidglass/ui/DynamicBitmapBackdrop.kt`
- `app/src/main/java/com/autumn/douyin/liquidglass/ui/BlackRegionPixelScanner.kt` (new)
- `app/src/main/java/com/autumn/douyin/liquidglass/nativebar/NativeBottomBarHierarchyDumper.kt`
- `app/build.gradle.kts` (versionCode/versionName only)
