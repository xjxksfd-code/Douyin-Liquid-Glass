package com.autumn.douyin.liquidglass.nativebar

import com.autumn.douyin.liquidglass.ModuleLog
import android.graphics.Rect
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

data class NativeBottomBar(
    val home: View,
    val friends: View,
    val plus: View,
    val messages: View,
    val profile: View,
) {
    val tabs: List<View> = listOf(home, friends, messages, profile)
    val all: List<View> = listOf(home, friends, plus, messages, profile)

    val selectedIndex: Int
        get() = selectedIndexOrNull() ?: 0

    /**
     * Returns the native tab selection without manufacturing a value while
     * Douyin is in the middle of a navigation transition.
     */
    fun selectedIndexOrNull(): Int? =
        tabs.indexOfFirst { it.isSelected }.takeIf { it >= 0 }

    fun clickTab(index: Int): Boolean = tabs.getOrNull(index)?.performClick() == true

    fun clickPlus(): Boolean = plus.performClick()

    fun longClickPlus(): Boolean = plus.performLongClick()

    fun suppressOriginalUi() {
        all.forEach { view ->
            view.visibility = View.INVISIBLE
            view.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }

        // Douyin can keep the native bottom-nav container's background after its
        // child buttons are hidden. That background is what can appear as a
        // dark strip beside the four liquid-glass tabs. Clear only the shared
        // immediate parent of the native controls; do not hide or resize it,
        // because the native views are still used for click/state synchronization.
        clearNativeBottomBackgrounds()

        // Re-apply after navigation/layout updates in case Douyin restores
        // the native bottom-nav background during its own rendering pass.
        val anchor = all.firstOrNull()
        anchor?.postDelayed({ clearNativeBottomBackgrounds() }, 120L)
        anchor?.postDelayed({ clearNativeBottomBackgrounds() }, 500L)
        anchor?.postDelayed({ clearNativeBottomBackgrounds() }, 1200L)
        anchor?.postDelayed({ clearNativeBottomBackgrounds() }, 2000L)
    }

    private fun clearNativeBottomBackgrounds() {
        all.firstOrNull() ?: return
        val commonParent = findCommonAncestor(all) ?: return

        // Walk only the compact ancestors that can represent the native
        // bottom-navigation container. Do not touch the activity/root view:
        // the root may own the whole page background.
        var current: View? = commonParent
        var cleared = 0
        var isFirstAncestor = true
        while (current is ViewGroup) {
            val heightDp = current.height / current.resources.displayMetrics.density
            val bottom = current.bottom
            val screenHeight = current.rootView.height
            val isBottomArea = screenHeight <= 0 || bottom >= screenHeight - dp(current, 120f)

            // The common parent is the native bottom-nav host. At very small
            // liquid-glass scales, any background/elevation left on this host
            // becomes visible beside the shrunken pill. Clear the common parent
            // unconditionally, then only continue into compact bottom ancestors.
            val shouldClear = isFirstAncestor || (heightDp <= 240f && isBottomArea)
            if (!shouldClear) break

            if (current.background != null) {
                current.background = null
                cleared++
            }
            current.backgroundTintList = null
            current.foreground = null
            current.elevation = 0f
            current.stateListAnimator = null

            isFirstAncestor = false
            current = current.parent as? ViewGroup
        }

        // The remaining artifact seen at the far-right edge can be a sibling
        // surface inside the same native bottom-nav host rather than the host
        // itself. Clear visual-only surfaces throughout this compact subtree,
        // while keeping every native control attached/clickable for state sync.
        val subtreeCleared = clearDescendantVisualLayers(commonParent)
        cleared += subtreeCleared

        // Some Douyin builds place the dark surface in a sibling of the tab
        // row, one level above commonParent. Clearing backgrounds inside the
        // row cannot remove a sibling that draws its own custom surface.
        // Scrub only unknown views inside the compact bottom-navigation
        // subtree, while preserving the five native controls used for state
        // synchronization. Alpha=0 keeps those unknown views attached and
        // interactive if Douyin later reuses them, unlike INVISIBLE/GONE.
        val siblingScrubbed = scrubUnknownBottomVisuals(commonParent)
        cleared += siblingScrubbed

        if (cleared > 0) {
            ModuleLog.info {
                "native bottom-nav visual layers cleared=$cleared " +
                    "commonParent=${commonParent.javaClass.name}"
            }
        }

        // If the common parent itself is not a compact bottom container,
        // retain the original immediate-parent fallback.
        if (cleared == 0) {
            clearImmediateParentBackground()
        }
    }

    private fun clearDescendantVisualLayers(root: View): Int {
        var cleared = 0

        fun clear(view: View) {
            if (view !== root) {
                var changed = false
                if (view.background != null) {
                    view.background = null
                    changed = true
                }
                if (view.backgroundTintList != null) {
                    view.backgroundTintList = null
                    changed = true
                }
                if (view.foreground != null) {
                    view.foreground = null
                    changed = true
                }
                if (view.elevation != 0f) {
                    view.elevation = 0f
                    changed = true
                }
                if (view.stateListAnimator != null) {
                    view.stateListAnimator = null
                    changed = true
                }
                if (view.clipToOutline) {
                    view.clipToOutline = false
                    changed = true
                }
                if (changed) cleared++
            }

            if (view is ViewGroup) {
                for (index in 0 until view.childCount) {
                    clear(view.getChildAt(index))
                }
            }
        }

        clear(root)
        return cleared
    }


    private fun scrubUnknownBottomVisuals(commonParent: ViewGroup): Int {
        val knownIds = all.mapTo(HashSet()) { System.identityHashCode(it) }
        val knownBounds = all.mapNotNull { view ->
            if (!view.isAttachedToWindow || view.width <= 0 || view.height <= 0) return@mapNotNull null
            val location = IntArray(2)
            view.getLocationInWindow(location)
            Rect(
                location[0],
                location[1],
                location[0] + view.width,
                location[1] + view.height,
            )
        }
        if (knownBounds.isEmpty()) return 0

        val targetRegion = Rect(
            knownBounds.minOf { it.left },
            knownBounds.minOf { it.top },
            knownBounds.maxOf { it.right },
            knownBounds.maxOf { it.bottom },
        )

        // Climb only through compact bottom-area ancestors. Never reach the
        // full-screen activity root, because unrelated feed controls must not
        // be hidden.
        var root: ViewGroup = commonParent
        repeat(3) {
            val parent = root.parent as? ViewGroup ?: return@repeat
            val density = root.resources.displayMetrics.density
            val heightDp = parent.height / density
            val location = IntArray(2)
            parent.getLocationInWindow(location)
            val parentBottom = location[1] + parent.height
            val screenHeight = parent.rootView.height
            val bottomArea = screenHeight <= 0 ||
                parentBottom >= screenHeight - dp(parent, 140f)
            if (heightDp > 320f || !bottomArea) return@repeat
            root = parent
        }

        var changed = 0

        fun containsKnown(view: View): Boolean {
            if (System.identityHashCode(view) in knownIds) return true
            if (view is ViewGroup) {
                for (index in 0 until view.childCount) {
                    if (containsKnown(view.getChildAt(index))) return true
                }
            }
            return false
        }

        fun scrub(view: View) {
            if (System.identityHashCode(view) in knownIds) return
            if (containsKnown(view)) {
                if (view is ViewGroup) {
                    for (index in 0 until view.childCount) scrub(view.getChildAt(index))
                }
                return
            }

            val location = IntArray(2)
            view.getLocationInWindow(location)
            val bounds = Rect(
                location[0],
                location[1],
                location[0] + view.width,
                location[1] + view.height,
            )
            if (view.isShown && Rect.intersects(targetRegion, bounds)) {
                val hasVisualLayer =
                    view.background != null ||
                        view.foreground != null ||
                        view.elevation != 0f ||
                        view.alpha != 0f
                if (hasVisualLayer) {
                    if (view.alpha != 0f) {
                        view.alpha = 0f
                        changed++
                    }
                    view.background = null
                    view.backgroundTintList = null
                    view.foreground = null
                    view.elevation = 0f
                    view.stateListAnimator = null
                }
            }

            if (view is ViewGroup) {
                for (index in 0 until view.childCount) scrub(view.getChildAt(index))
            }
        }

        for (index in 0 until root.childCount) {
            scrub(root.getChildAt(index))
        }

        if (changed > 0) {
            ModuleLog.info {
                "native bottom-nav unknown sibling visuals scrubbed=$changed " +
                    "root=${root.javaClass.name} region=$targetRegion"
            }
        }
        return changed
    }

    private fun clearImmediateParentBackground() {
        val parents = all.mapNotNull { it.parent as? ViewGroup }
        val sharedParent = parents.firstOrNull()?.takeIf { parent ->
            parents.all { it === parent }
        } ?: return
        sharedParent.background = null
        sharedParent.backgroundTintList = null
    }

    private fun findCommonAncestor(views: List<View>): ViewGroup? {
        val firstAncestors = generateSequence(views.firstOrNull()?.parent as? ViewGroup) {
            it.parent as? ViewGroup
        }.toList()
        return firstAncestors.firstOrNull { candidate ->
            views.all { view ->
                generateSequence(view.parent as? ViewGroup) { it.parent as? ViewGroup }
                    .any { it === candidate }
            }
        }
    }

    private fun dp(view: View, value: Float): Float =
        value * view.resources.displayMetrics.density

    fun describe(): String = all.joinToString(separator = ", ") { view ->
        val resourceName = view.id
            .takeIf { it != View.NO_ID }
            ?.let { id -> runCatching { view.resources.getResourceName(id) }.getOrNull() }
        "${view.javaClass.simpleName}(${resourceName ?: "no-id"}, ${view.width}x${view.height})"
    }

    fun boundsInWindow(): Rect? {
        if (all.any { !it.isAttachedToWindow || it.width <= 0 || it.height <= 0 }) return null

        val location = IntArray(2)
        var left = Int.MAX_VALUE
        var top = Int.MAX_VALUE
        var right = Int.MIN_VALUE
        var bottom = Int.MIN_VALUE
        all.forEach { view ->
            view.getLocationInWindow(location)
            left = minOf(left, location[0])
            top = minOf(top, location[1])
            right = maxOf(right, location[0] + view.width)
            bottom = maxOf(bottom, location[1] + view.height)
        }
        if (left >= right || top >= bottom) return null
        return Rect(left, top, right, bottom)
    }
}

object NativeBottomBarLocator {
    fun find(root: ViewGroup): NativeBottomBar? {
        findByGeometry(root)?.let { return it }
        return findByLabels(root)
    }

    private fun findByGeometry(root: ViewGroup): NativeBottomBar? {
        if (root.width <= 0 || root.height <= 0) return null

        val location = IntArray(2)
        val candidates = mutableListOf<Candidate>()
        collectViews(root) { view ->
            if (!view.isShown || !view.isClickable || !view.isEnabled) return@collectViews
            val widthRatio = view.width.toFloat() / root.width.toFloat()
            if (widthRatio !in 0.12f..0.28f) return@collectViews
            if (view.height <= 0 || view.height > root.height / 3) return@collectViews

            view.getLocationInWindow(location)
            val bottom = location[1] + view.height
            if (bottom < root.height - (root.height * 0.04f)) return@collectViews
            candidates += Candidate(view, location[0], location[1])
        }

        if (candidates.size < 5) return null

        val bottomRow = candidates
            .groupBy { it.top }
            .maxByOrNull { group -> group.value.sumOf { candidate -> candidate.view.width } }
            ?.value
            ?.sortedBy { it.left }
            ?.take(5)
            ?: return null

        if (bottomRow.size < 5) return null
        return NativeBottomBar(
            home = bottomRow[0].view,
            friends = bottomRow[1].view,
            plus = bottomRow[2].view,
            messages = bottomRow[3].view,
            profile = bottomRow[4].view,
        )
    }

    private fun findByLabels(root: ViewGroup): NativeBottomBar? {
        val home = findClickableByLabel(root, "首页") ?: return null
        val friends = findClickableByLabel(root, "朋友") ?: return null
        val messages = findClickableByLabel(root, "消息") ?: return null
        val profile = findClickableByLabel(root, "我") ?: return null
        val plus = findClickableByDescription(root, "拍") ?: return null
        return NativeBottomBar(home, friends, plus, messages, profile)
    }

    private fun collectViews(view: View, action: (View) -> Unit) {
        action(view)
        if (view is ViewGroup) {
            for (index in 0 until view.childCount) {
                collectViews(view.getChildAt(index), action)
            }
        }
    }

    private fun findClickableByLabel(root: ViewGroup, label: String): View? =
        findFirst(root) { view ->
            if (view !is TextView) return@findFirst false
            view.text?.toString() == label || view.contentDescription?.toString()?.startsWith(label) == true
        }?.closestClickable(root)

    private fun findClickableByDescription(root: ViewGroup, keyword: String): View? =
        findFirst(root) { view ->
            view.contentDescription?.toString()?.contains(keyword) == true
        }?.closestClickable(root)

    private fun findFirst(root: ViewGroup, predicate: (View) -> Boolean): View? {
        var result: View? = null
        collectViews(root) { view ->
            if (result == null && predicate(view)) result = view
        }
        return result
    }

    private fun View.closestClickable(root: ViewGroup): View? {
        var current: View = this
        while (current !== root) {
            if (current.isClickable) return current
            current = current.parent as? View ?: return null
        }
        return null
    }

    private data class Candidate(
        val view: View,
        val left: Int,
        val top: Int,
    )
}
