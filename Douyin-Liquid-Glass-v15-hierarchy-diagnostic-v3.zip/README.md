V14 - tiny-scale black-edge geometry fix

Based on V13. Fixes the small-scale black edge by keeping the full-width transparent overlay host unscaled and applying bar scale only to the actual glass pill. This prevents transparent side regions of a scaled host from exposing the native bottom-nav background.

Preserved: four tabs 首页/朋友/消息/我的, plus removed, live glass/backdrop, touch/click behavior, size/length/vertical position controls, 70-200% length limit, tab sync, message badge, and progress touch fix.
Version: 1.0.9 (139)
