# Douyin Liquid Glass V5 — Refraction Mapping Fix

This V5 source is based on the supplied project source and targets the specific
refraction-mapping issue reported for the bottom glass bar.

## What changed

- The backdrop capture rectangle may still include extra pixels around the bar,
  so the lens shader has enough source pixels for refraction.
- That capture/effect padding is no longer used to shift the base backdrop image
  mapping or the destination drawing coordinates.
- The visible glass keeps its own screen/layout coordinates; the lens shader is
  responsible for applying the actual refraction offset.
- The same coordinate rule is applied to the composite-frame path.
- Version bumped to 1.1.3 / versionCode 143.

## Intentionally not changed

- The intermittent touch/scroll freeze issue is not addressed in this version.
- No additional performance changes were made.
