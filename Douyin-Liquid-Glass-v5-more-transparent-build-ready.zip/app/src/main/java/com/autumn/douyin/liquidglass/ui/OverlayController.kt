package com.autumn.douyin.liquidglass.ui

import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.autumn.douyin.liquidglass.ModuleLog
import com.autumn.douyin.liquidglass.nativebar.NativeBottomBar
import com.autumn.douyin.liquidglass.nativebar.NativeMessageBadgeMonitor

class OverlayController(private val nativeBar: NativeBottomBar) {
    var selectedTab by mutableIntStateOf(nativeBar.selectedIndex)
        private set
    var messageBadgeCount by mutableIntStateOf(0)
        private set


    private fun finishBackPreview() {
        if (!running) return
        syncSelectedTab()
        if (selectedTab == 0) {
            predictiveBackProgress = 0f
        } else {
            mainHandler.postDelayed({ finishBackPreview() }, 16L)
        }
    }

    private val messageBadgeMonitor = NativeMessageBadgeMonitor(nativeBar.messages) {
        messageBadgeCount = it
    }

    // The liquid bar used to update its selection only when the user tapped
    // the liquid bar itself. A Douyin back-swipe changes the native tab
    // selection without going through clickTab(), so the Compose indicator
    // could remain on the old tab. Keep the overlay state synchronized with
    // the real native tab state as well.
    private val mainHandler = Handler(Looper.getMainLooper())
    private val selectionPoller = object : Runnable {
        override fun run() {
            if (!running) return
            syncSelectedTab()
            mainHandler.postDelayed(this, SelectionPollIntervalMs)
        }
    }
    private var running = false

    fun start() {
        if (running) return
        running = true
        messageBadgeMonitor.start()
        syncSelectedTab()
        mainHandler.post(selectionPoller)
    }

    fun stop() {
        if (!running) return
        running = false
        mainHandler.removeCallbacks(selectionPoller)
        messageBadgeMonitor.stop()
    }

    private fun syncSelectedTab() {
        val nativeIndex = nativeBar.selectedIndexOrNull() ?: return
        if (nativeIndex != selectedTab) {
            ModuleLog.info {
                "sync liquid tab from native: $selectedTab -> $nativeIndex"
            }
            selectedTab = nativeIndex
        }
    }

    fun clickTab(index: Int) {
        selectedTab = index
        val accepted = nativeBar.clickTab(index)
        nativeBar.tabs[index].postDelayed({
            nativeBar.selectedIndexOrNull()?.let { selectedTab = it }
        }, 240)
        ModuleLog.info { "click tab=$index accepted=$accepted" }
    }

    fun clickPlus() {
        val accepted = nativeBar.clickPlus()
        ModuleLog.info { "click plus accepted=$accepted" }
    }

    fun longClickPlus(): Boolean {
        val accepted = nativeBar.longClickPlus()
        ModuleLog.info { "long click plus accepted=$accepted" }
        return accepted
    }

    private companion object {
        const val SelectionPollIntervalMs = 16L
    }
}
