package com.autumn.douyin.liquidglass.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import com.autumn.douyin.liquidglass.ModuleLog
import com.autumn.douyin.liquidglass.nativebar.NativeBottomBar
import com.autumn.douyin.liquidglass.nativebar.NativeMessageBadgeMonitor

class OverlayController(private val nativeBar: NativeBottomBar) {
    var selectedTab by mutableIntStateOf(nativeBar.selectedIndex)
        private set
    var messageBadgeCount by mutableIntStateOf(0)
        private set

    private val messageBadgeMonitor = NativeMessageBadgeMonitor(nativeBar.messages) {
        messageBadgeCount = it
    }

    fun start() {
        messageBadgeMonitor.start()
    }

    fun stop() {
        messageBadgeMonitor.stop()
    }

    /**
     * Mirrors the actual native selection without generating a native click.
     * Used by back-navigation observation so the glass bar follows Douyin's
     * own navigation result instead of predicting the destination.
     */
    fun syncFromNative(source: String = "native") {
        val nativeIndex = nativeBar.selectedIndexOrNull ?: return
        if (nativeIndex == selectedTab) return
        selectedTab = nativeIndex
        ModuleLog.info { "sync selected tab=$nativeIndex source=$source" }
    }

    fun clickTab(index: Int) {
        selectedTab = index
        val accepted = nativeBar.clickTab(index)
        nativeBar.tabs[index].postDelayed({
            selectedTab = nativeBar.selectedIndex
        }, 240)
        ModuleLog.info { "click tab=$index accepted=$accepted" }
    }

    fun clickPlus() {
        val accepted = nativeBar.clickPlus()
        ModuleLog.info { "click plus accepted=$accepted" }
    }

    fun longClickPlus(): Boolean {
        val accepted = nativeBar.longClickPlus()
        ModuleLog.info { "long click plus accepted=$accepted" }
        return accepted
    }

}
