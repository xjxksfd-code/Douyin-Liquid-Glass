package com.autumn.douyin.liquidglass.hook

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.autumn.douyin.liquidglass.ModuleLog
import com.autumn.douyin.liquidglass.ui.OverlayController
import de.robv.android.xposed.XC_MethodHook
import de.robv.android.xposed.XposedHelpers
import java.util.Collections
import java.util.WeakHashMap

/**
 * Observes back navigation without consuming or replacing the app's back
 * handling. After the real back callback returns, the native selected state
 * is sampled immediately and on a few short follow-up frames.
 *
 * This is intentionally separate from NativeBottomBarStateMonitor: its 100ms
 * polling interval is left untouched. These samples are a back-event burst,
 * not a replacement monitor.
 */
class BackNavigationSync(
    private val activity: Activity,
    private val controller: OverlayController,
) {
    fun start() {
        synchronized(registry) {
            registry[activity] = controller
            if (!hooksInstalled) installHooks(activity.classLoader)
        }
        ModuleLog.info("back navigation sync registered activity=${activity.javaClass.name}")
    }

    fun stop() {
        synchronized(registry) {
            registry.remove(activity)
        }
        handler.removeCallbacksAndMessages(activity)
    }

    companion object {
        private const val DedupWindowMs = 8L
        private val handler = Handler(Looper.getMainLooper())
        private val registry = Collections.synchronizedMap(WeakHashMap<Activity, OverlayController>())
        private val lastDispatch = Collections.synchronizedMap(WeakHashMap<Activity, Long>())
        private val FollowUpDelaysMs = longArrayOf(16L, 32L, 64L, 128L, 240L)
        @Volatile
        private var hooksInstalled = false

        private fun installHooks(classLoader: ClassLoader) {
            if (hooksInstalled) return
            val hook = object : XC_MethodHook() {
                override fun afterHookedMethod(param: MethodHookParam) {
                    val activity = param.thisObject as? Activity ?: return
                    schedule(activity, "callback")
                }
            }

            runCatching {
                XposedHelpers.findAndHookMethod(
                    Activity::class.java,
                    "onBackPressed",
                    hook,
                )
            }.onFailure { ModuleLog.error("failed to hook Activity.onBackPressed", it) }

            runCatching {
                XposedHelpers.findAndHookMethod(
                    "androidx.activity.ComponentActivity",
                    classLoader,
                    "onBackPressed",
                    hook,
                )
            }.onFailure { ModuleLog.info("ComponentActivity.onBackPressed hook unavailable") }

            hooksInstalled = true
            ModuleLog.info("back navigation hooks installed")
        }

        private fun schedule(activity: Activity, source: String) {
            val controller = synchronized(registry) { registry[activity] } ?: return
            val now = SystemClock.uptimeMillis()
            val last = synchronized(lastDispatch) { lastDispatch[activity] ?: 0L }
            if (now - last < DedupWindowMs) return
            synchronized(lastDispatch) { lastDispatch[activity] = now }

            controller.syncFromNative("back:$source")
            FollowUpDelaysMs.forEach { delay ->
                handler.postAtTime(
                    { synchronized(registry) { registry[activity] }?.syncFromNative("back:$source+$delay") },
                    activity,
                    SystemClock.uptimeMillis() + delay,
                )
            }
        }
    }
}
